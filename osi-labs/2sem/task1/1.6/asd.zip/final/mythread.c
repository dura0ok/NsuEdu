#define _GNU_SOURCE
#include "mythread.h"
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <setjmp.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <linux/futex.h>
#include <stdbool.h>
#include <limits.h>


#define STACK_SIZE (1 << 20)

volatile int NUM_ALIVE_THREADS = 1;
volatile int THREAD_COMPLETED = 0;

void* routine_wrapper(void *arg){
    mythread_t* t = (mythread_t *)arg;
    t->res = t->start_routine(t->arg);
    t->completed = 1;

    // Use futex to wake up threads waiting in mythread_join()
    syscall(SYS_futex, &t->completed, FUTEX_WAKE, 1, NULL, NULL, 0);

    mythread_exit();
}

int mythread_create(mythread_t *thread, void *(*start_routine)(void *), void *arg) {
    thread->arg = arg;
    thread->stack = mmap(NULL, STACK_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (thread->stack == MAP_FAILED) {
        perror("mmap");
        return -1;
    }
    thread->start_routine = start_routine;

    if (clone((int (*)(void *)) routine_wrapper, (char*)thread->stack + STACK_SIZE, CLONE_VM | CLONE_FS | CLONE_FILES | CLONE_SIGHAND | CLONE_THREAD, thread) == -1) {
        perror("clone");
        return -1;
    }

    thread->joined = 1;
    thread->completed = 0;
    __sync_fetch_and_add(&NUM_ALIVE_THREADS, 1);

    // Set lower priority for the joining thread
    struct sched_param param;
    param.sched_priority = 0; // Use 0 for SCHED_OTHER
    if (sched_setparam(0, &param) == -1) {
        perror("sched_setparam");
        return -1;
    }

    return 0;
}

void mythread_detach(mythread_t *t) {
    t->joined = 0;
}

int mythread_join(mythread_t *thread, void **ret_val) {
    if (thread->joined == 0) {
        return -1;
    }

    while (thread->completed == 0) {
        // Use futex to wait for completion
        syscall(SYS_futex, &thread->completed, FUTEX_WAIT, 0, NULL, NULL, 0);
    }

    if (ret_val != NULL) {
        *ret_val = thread->res;
    }

    munmap(thread->stack, STACK_SIZE); // Free the stack memory

    return 0;
}

void mythread_exit() {
    if (__sync_fetch_and_sub(&NUM_ALIVE_THREADS, 1) != 1) {
        syscall(SYS_futex, &NUM_ALIVE_THREADS, FUTEX_WAKE, INT_MAX, NULL, NULL, 0);
        pause();
    }
    exit(0);
}